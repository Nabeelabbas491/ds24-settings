import { createAction, createFeatureSelector, createReducer, createSelector, on, props } from "@ngrx/store";
import { BookingType } from "src/app/types/settings.type";

export const featureKey = 'settings';

export interface State {
    error: string | null;
    pending: boolean;
    bookingTypeSaveSuccess: BookingType | null;
    bookingTypeDetails: BookingType;
}

export const initialState: State = {
    error: null,
    pending: false,
    bookingTypeSaveSuccess: null,
    bookingTypeDetails: {
        outBoundPhoneCall: false,
        inBoundPhoneCall: false,
        phoneNumber: '',
        videoConference: false,
    }
};

export const actions = {
    saveBookingType: createAction('[Setting/API] Save Booking Type', props<{ form: BookingType }>()),
};

export const reducer = createReducer(
    initialState,
    on(actions.saveBookingType, (state, { form }) => ({ ...state, bookingTypeDetails: form })),
);

export const selectSlice = createFeatureSelector<State>(featureKey);

export const selectors = {
    selectBookingSaveError: createSelector(selectSlice, (state: State) => state.error),
    selectBookingSavePending: createSelector(selectSlice, (state: State) => state.pending),
    selectBookingTypeSaveSuccess: createSelector(selectSlice, (state: State) => state.bookingTypeSaveSuccess),
    selectBookingTypeDetails: createSelector(selectSlice, (state: State) => state.bookingTypeDetails),
};

