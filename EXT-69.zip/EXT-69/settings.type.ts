export interface BookingType {
    outBoundPhoneCall: boolean
    inBoundPhoneCall: boolean
    phoneNumber: string
    videoConference: boolean
}