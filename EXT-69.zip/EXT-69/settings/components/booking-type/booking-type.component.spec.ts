import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingTypeComponent } from './booking-type.component';
import { TranslateModule } from '@ngx-translate/core';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { State, selectors } from '../../../../store';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('BookingTypeComponent', () => {
  let component: BookingTypeComponent;
  let fixture: ComponentFixture<BookingTypeComponent>;
  let mockStore: MockStore<State>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [BookingTypeComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [provideMockStore()],
    });

    fixture = TestBed.createComponent(BookingTypeComponent);
    mockStore = TestBed.inject(MockStore);
    const mockData = {
      outBoundPhoneCall: false,
      inBoundPhoneCall: false,
      phoneNumber: '',
      videoConference: false,
    }
    mockStore.overrideSelector(selectors.settings.selectBookingTypeDetails, mockData);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
