import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import * as actions from '../../../../store/actions';
import * as selectors from '../../../../store/selectors';
import { Observable } from 'rxjs';
import { BookingType } from 'src/app/types/settings.type';

@Component({
  selector: 'ds-booking-type',
  templateUrl: './booking-type.component.html',
})
export class BookingTypeComponent {

  form$ = this.store.select(selectors.settings.selectBookingTypeDetails) as Observable<BookingType>;
  form: FormGroup = this.fb.group({
    outBoundPhoneCall: new FormControl('', { validators: [] }),
    inBoundPhoneCall: new FormControl('', { validators: [] }),
    phoneNumber: new FormControl('', { validators: [] }),
    videoConference: new FormControl('', { validators: [] }),
  })

  constructor(public fb: FormBuilder, private store: Store) {
    this.form$.subscribe((data) => { console.log("data...", data) })
  }

  connectZoom() {
    this.store.dispatch(actions.settings.saveBookingType({ form: this.form.value }))
  }


}
