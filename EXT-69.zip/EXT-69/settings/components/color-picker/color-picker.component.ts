import { Component } from '@angular/core';

@Component({
  selector: 'ds-color-picker',
  templateUrl: './color-picker.component.html',
})
export class ColorPickerComponent {

}
