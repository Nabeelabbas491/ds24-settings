import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LogoUploadComponent } from './logo-upload.component';
import { TranslateModule } from '@ngx-translate/core';
import { By } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

describe('LogoUploadComponent', () => {
  let component: LogoUploadComponent;
  let fixture: ComponentFixture<LogoUploadComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), FormsModule],
      declarations: [LogoUploadComponent]
    });
    fixture = TestBed.createComponent(LogoUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should detect file input change and call select File method when icon clicked", () => {
    jest.spyOn(component, "selectFile")
    const iconContainer = fixture.debugElement.query(By.css('#logo-div'));
    const input = fixture.debugElement.query(By.css('input[type=file]'));
    let iconBtnClicked = false
    iconContainer.triggerEventHandler("click", {})
    iconBtnClicked = true
    if (iconBtnClicked) {
      input.nativeElement.dispatchEvent(new InputEvent('change'));
    }
    fixture.detectChanges();
    expect(component.selectFile).toHaveBeenCalled()
  })

  it("should remove image on remove function called", () => {
    jest.spyOn(component, "remove")
    component.selectedlogo = "test-logo"
    fixture.detectChanges();
    const removeBtn = fixture.debugElement.query(By.css('#remove-btn'));
    removeBtn.triggerEventHandler("click", {})
    fixture.detectChanges();
    expect(component.selectedlogo).toEqual('')
    expect(component.logoPath).toEqual('')
  })

});
