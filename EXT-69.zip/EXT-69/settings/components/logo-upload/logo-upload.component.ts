import { Component } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Component({
  selector: 'ds-logo-upload',
  templateUrl: './logo-upload.component.html',
})
export class LogoUploadComponent {

  selectedlogo: string | SafeUrl = "";
  logoPath: string = '';
  files: any;

  constructor(private sanitizer: DomSanitizer) { }

  selectFile(event: any) {
    this.files = event.target.files
    this.selectedlogo = this.sanitizer.bypassSecurityTrustUrl(
      window.URL.createObjectURL(this.files[0])
    );
  }

  remove() {
    this.selectedlogo = '';
    this.logoPath = ''
  }

}
