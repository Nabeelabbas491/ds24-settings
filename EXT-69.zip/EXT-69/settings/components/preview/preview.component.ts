import { Component } from '@angular/core';

@Component({
  selector: 'ds-preview',
  templateUrl: './preview.component.html',
})
export class PreviewComponent {

}
